import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("37e9d242-7abe-444a-9af6-3c98fbe080ec")
public class AdministrativeResponsibility {
    @objid ("e0cce675-9422-4cbf-bee3-a590a96912d7")
    public String description;

}
