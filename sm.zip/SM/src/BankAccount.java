import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d21deaeb-0222-400c-b7c0-cc22ee72881c")
public class BankAccount {
    @objid ("2f5342b7-d6f1-45fd-a8b1-0d7a1bb7b4a9")
    public String accountID;

    @objid ("161e6cc5-02c2-430b-94c2-e9e5c5fac753")
    public String accountDetails;

    @objid ("a1531429-f8ec-4bf7-b2a0-2958aa70bf30")
    public double balance;

}
