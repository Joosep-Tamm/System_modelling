import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4929ec5a-9882-4ab9-b7db-0aa3f6dd7983")
public class Car {
    @objid ("a86cb254-fb42-46e0-8bec-072f285848e1")
    public int humanCapacity;

    @objid ("c552de02-619e-43dd-988b-bb90eda2142f")
    public int scooterCapacity;

}
