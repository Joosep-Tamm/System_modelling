import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2db3c459-66da-426a-89c1-997a1b6a2e7c")
public class Employee extends User {
    @objid ("e5a381d4-f52b-4527-b6ff-cbd0b51f9a7d")
    public double monthlySalary;

    @objid ("40114e76-cf15-4c2c-8b90-04b9f6673a1b")
    public String department;

}
