import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6af6b6d7-5e99-43e7-aee1-39249ff25065")
public class HumanResourceManager extends Employee {
    @objid ("3c01d9a6-28ad-4e92-8c5c-17e723a4d63f")
    public AdministrativeResponsibility administrativeResponsibility;

    @objid ("e314619b-f7e7-42d8-9b99-07eaf73d3f73")
    public List<Employee> managed = new ArrayList<Employee> ();

    @objid ("fc420991-bf2a-4519-a488-9ccdcfe5f5ce")
    public List<AdministrativeResponsibility> belongs to = new ArrayList<AdministrativeResponsibility> ();

}
