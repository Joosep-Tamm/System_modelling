import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("684e9e9e-30f1-4d22-bfc5-2f22e8b4ad33")
public class Invoice {
    @objid ("70d51def-3fdb-46d6-bb1e-6400a78b3e9d")
    public String invoiceNumber;

    @objid ("76eab333-c5e1-49f1-b6da-44107d96ba4a")
    public Date issuedDate;

    @objid ("d2c5826a-7c82-4894-8a3f-e9091e96955e")
    public String billingDetails;

    @objid ("c2de4a3b-7146-4101-a10e-2727b0c1c207")
    public Map<String, PaymentTransaction> covered = new HashMap<String, PaymentTransaction> ();

}
