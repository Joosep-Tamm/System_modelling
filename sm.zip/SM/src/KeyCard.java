import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("61c48df5-c1de-436c-afa4-49f1c7635623")
public class KeyCard {
    @objid ("d56dd15a-bb3c-4979-880e-94e3b0503782")
    public String cardId;

    @objid ("72f66807-764c-4079-a2c5-6307f8fb4876")
    public Date issuedDate;

    @objid ("1e448f8f-fe36-4893-898f-c7f2c3eb6abb")
    public Map<String, Rider> owner = new HashMap<String, Rider> ();

}
