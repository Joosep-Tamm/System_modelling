import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1505f775-0d3b-4ac8-a932-f4835420e34d")
public class Map {
    @objid ("fd6d9c1e-d675-499b-a390-1c42b6f2915e")
    public String apiKey;

    @objid ("545132a0-a83d-46c4-a501-033245ee797e")
    public List<ParkingZone> contained = new ArrayList<ParkingZone> ();

}
