import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6c88cce2-de2e-45b2-928c-4f862e4cdd9f")
public class ParkingZone {
    @objid ("cf691e7d-7773-45dc-b917-4dc206452b40")
    public String zoneId;

    @objid ("2ac0663e-b5ee-4703-98c4-301f8c6b81e4")
    public String name;

    @objid ("92430865-39a4-4bf3-90ca-cbdf6727cae2")
    public String location;

    @objid ("d34e7e13-8f1f-4b4d-9aff-4961645a0927")
    public Map shows;

}
