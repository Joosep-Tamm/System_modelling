import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3547bd84-0260-4f26-9e1e-c766880bb98a")
public class PaymentTransaction {
    @objid ("f2c1e871-2351-447f-bbbd-b88c7a3ba852")
    public String transactionId;

    @objid ("3dff3c84-8518-4096-874f-37b7056e40f6")
    public Date timestamp;

    @objid ("d9b00670-b2b9-46ea-989a-34e9e1e57957")
    public double amount;

    @objid ("c4bf7f83-d90a-4f97-a2f4-6905e204b563")
    public String paymentMethod;

    @objid ("b66877e9-ff01-4c7d-871c-1dad241e0ab0")
    public Map<String, Trip> paid for = new HashMap<String, Trip> ();

    @objid ("4c9efa5b-4a0b-48a5-8b45-43e3817c9c2a")
    public Map<String, Rider> pays = new HashMap<String, Rider> ();

}
