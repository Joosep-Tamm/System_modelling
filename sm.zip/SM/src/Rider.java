import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f795ec31-00b8-40f0-bc58-6274401a69ea")
public class Rider extends User {
    @objid ("fa17cdc8-48b9-49d6-9e3f-470502f7b280")
    public BankAccount bankAccount;

    @objid ("e0f6ae6f-7bd9-42ae-af2d-a722e8a684fc")
    public List<Trip> taken = new ArrayList<Trip> ();

    @objid ("c314b007-51f8-4f82-a437-15da4ee25519")
    public BankAccount linked;

    @objid ("c81e1c4c-677b-4998-9348-f4b15bea3eff")
    public Map<String, KeyCard> owned = new HashMap<String, KeyCard> ();

}
