import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9f82ce34-3d4f-4552-9b68-8a6b17344fea")
public class Scooter {
    @objid ("a015bd8e-9d0b-4fb0-9828-acd1d247071e")
    public String id;

    @objid ("b7f94646-972d-45c9-ad87-1cf32ff44d09")
    public int batteryLevel;

}
