import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2adf7d41-14ad-4acd-8274-4474033882a8")
public class Scooter {
    @objid ("26283be9-5afb-4498-bf54-1f7277f48c73")
    public String scooterId;

    @objid ("6df3dd74-e4bc-434b-a723-d3129cb76069")
    public int batteryLevel;

    @objid ("8f619841-88b1-4d41-afbe-30e4f8fadcdf")
    public String currentLocation;

    @objid ("7f56d530-0e97-46e6-a6e0-70b9602ff593")
    public String qrCode;

    @objid ("71bba7d6-e05b-40d9-b7c8-3f27ec946e27")
    public ScooterStatus status;

    @objid ("61ff1b98-631e-42f5-8b1e-7ef5bd8902c3")
    public ScooterStatus applied;

}
