import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("981b275a-4487-49c3-9a47-4d7ae0f5b234")
public class ScooterStatus {
    @objid ("4a92958c-cd34-4568-b563-34551fa0a177")
    public String lastUpdated;

    @objid ("e5ca8048-02f8-44ae-9b8f-dded66ec7dba")
    public statusType status;

}
