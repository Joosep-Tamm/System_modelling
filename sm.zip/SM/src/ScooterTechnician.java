import java.util.HashMap;
import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4c21a717-0734-4bb1-9852-37452303710b")
public class ScooterTechnician extends Employee {
    @objid ("79799b9e-c1ab-4efe-ac2b-cd3fa20b2c48")
    public Car car;

    @objid ("1879cad1-32d6-4718-92a8-06e9c73ee589")
    public Car used;

    @objid ("54f8f66a-b145-4f30-b95d-36cc106822e9")
    public Map<String, Scooter> maintained = new HashMap<String, Scooter> ();

}
