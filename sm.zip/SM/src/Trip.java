import java.util.HashMap;
import java.util.Map;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e8aab345-33f4-4c88-8aae-47dd2c2fd2b5")
public class Trip {
    @objid ("56969b7e-c162-490f-ac44-d77f4246c342")
    public String tripId;

    @objid ("dbc78f90-2ce2-4e9b-bd95-1d21b0478fdb")
    public String startLocation;

    @objid ("b35fa8e6-d1d7-473d-b50f-47b74ba788fe")
    public String endLocation;

    @objid ("0acef667-32f9-4b5a-aea5-d6886570fc19")
    public double duration;

    @objid ("f7652a26-13af-402b-a378-01ee27dbf03a")
    public double travelDistance;

    @objid ("441df226-91d8-405c-a128-fb5016f6739f")
    public Map<String, Scooter> used = new HashMap<String, Scooter> ();

}
