import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0b07b7e1-ed0e-40ee-9400-c38bd12158e5")
public abstract class User {
    @objid ("c708d748-494b-42cf-bf92-792626ea2618")
    public String userId;

    @objid ("57e9f82f-ddf4-4143-aefd-780923c263cb")
    public String name;

    @objid ("550b9513-723b-414c-b904-2f63769ddda9")
    public String phone;

    @objid ("90b14b79-84fd-4077-9564-88a1a3f67f43")
    public String email;

}
