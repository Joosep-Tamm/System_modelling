import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("cb73d258-b1b9-4c84-be61-feae3e0b8e69")
public enum statusType {
    available,
    inUse,
    charging,
    outOfService;
}
